#include "diary.h"
int main() {
	memo();
	calendar();
	return 0;
}

