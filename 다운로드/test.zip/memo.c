#include <stdio.h>
int memo() {
	printf("func memo. \n");
	return 0;
}

