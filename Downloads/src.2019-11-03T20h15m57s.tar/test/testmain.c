#include "testlib.h"
#include "log.c/src/log.h"
#include <stdio.h>

int main(int argc, char **argv) {
#ifdef TESTFAIL
	log_warn("TESTFAIL has set -- testsuite will always failed.");
#else
	log_debug("Running tests...");
#endif
	return munit_suite_main(&test_suite, (void *)"µnit", argc, argv);
}

