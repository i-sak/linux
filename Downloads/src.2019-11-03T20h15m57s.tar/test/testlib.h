#ifndef _TESTLIB_H
#define _TESTLIB_H

#include "munit/munit.h"

extern const MunitSuite test_suite;

#endif

