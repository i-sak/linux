#ifndef _INC_MY_ASSERT_H
#define _INC_MY_ASSERT_H

#include "inc/boolean.h"
#include "inc/assert_driver.h"

extern assert_driver default_assert_driver;

extern void my_assert(bool expr, const char *mesaage);
extern void my_assert_with(assert_driver driver, bool expr, const char *message);

#endif

