typedef unsigned char bool;
