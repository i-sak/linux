#ifndef _INC_MY_MATH_H
#define _INC_MY_MATH_H

extern int idivide(int a, int b);
extern int iabs(int n);
extern int ipow(int n, int exp);

#endif

