#ifndef _INC_ASSERT_DRIVER_H
#define _INC_ASSERT_DRIVER_H

typedef void(*assert_driver)(const char *message);

extern void c_assert_driver(const char *message);
extern void stderr_assert_driver(const char *message);

#endif

