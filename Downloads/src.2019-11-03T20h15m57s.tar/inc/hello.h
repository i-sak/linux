#ifndef _INC_HELLO_H
#define _INC_HELLO_H

extern const char *k_hello_world;

extern void say_hello(void);

#endif

