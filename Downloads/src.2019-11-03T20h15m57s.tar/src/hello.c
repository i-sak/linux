#include "inc/hello.h"
#include "log.c/src/log.h"
#include <stdio.h>

const char *k_hello_world = "Hello, world!";

void say_hello(void) {
	log_trace("in say_hello():");
	printf("%s", k_hello_world);
}
