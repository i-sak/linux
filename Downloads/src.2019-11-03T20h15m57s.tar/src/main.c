#include "inc/hello.h"
#include "inc/my_math.h"
//#include "lib/logging/logging.h"
#include "log.c/src/log.h"
#include <stdio.h>

int main(int argc, char **argv) {
	int divider = (argc > 1) ? (argv[1][0] - '0') : 1;

#ifdef DEBUG
	log_debug("Debug build.");
#endif

	log_info("version 1.0");
	log_trace("in main():");

	say_hello();
	printf("\n");

	printf("ipow(2, 2)=%d\n", ipow(2, 2));
	printf("iabs(-10)=%d\n", iabs(-10));


	printf("idivide(5, %d)=%d\n", divider, idivide(5, divider));

	log_trace("main() has ended.");
}
