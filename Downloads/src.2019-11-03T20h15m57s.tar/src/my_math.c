#include "inc/my_math.h"
#include "inc/my_assert.h"
#include <math.h>

int idivide(int a, int b) {
	my_assert(b != 0, "Divide by zero.");
	return a / b;
}

int iabs(int n) {
	return n < 0 ? -n : n;
}

int ipow(int n, int exp) {
	return n == 2 ? (1 << exp) : (int)pow(n, exp);
}

