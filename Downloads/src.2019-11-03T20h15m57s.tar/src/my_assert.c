#include "inc/my_assert.h"
#include "inc/assert_driver.h"
#include "log.c/src/log.h"
#include <stdlib.h>

assert_driver default_assert_driver = stderr_assert_driver;

void my_assert(bool expr, const char *message) {
	log_trace("in my_assert():");
	if (!expr) {
		log_trace("Assertion has failed.");
		default_assert_driver(message);
		exit(-1);
	}
}

void my_assert_with(assert_driver driver, bool expr, const char *message) {
	log_trace("in my_assert_with():");
	if (!expr) {
		driver(message);
		exit(-1);
	}
}

