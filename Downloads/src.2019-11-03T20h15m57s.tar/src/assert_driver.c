#include "inc/assert_driver.h"
#include <assert.h>
#include <stdio.h>

void c_assert_driver(const char *message) {
	assert(message);
}

void stderr_assert_driver(const char *message) {
	fprintf(stderr, "%s\n", message);
}

